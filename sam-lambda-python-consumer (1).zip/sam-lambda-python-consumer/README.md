# sam-lambda-python-consumer

This project contains source code and supporting files for a serverless application that you can deploy with the SAM CLI.
